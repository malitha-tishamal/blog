<?php
$conn = mysqli_connect("localhost", "root", "", "blog");

if (!$conn) {
    die("DB Connection Failed");
}
?>
