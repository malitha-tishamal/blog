<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=5.0">
  
  <!-- Primary Title with Focus Keywords -->
  <title>MediQ Antibiogram Management System | Antimicrobial Resistance Tracking & Analysis Platform</title>
    <!-- Favicons -->
  <link href="assets/img/favicon.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">
  <!-- Comprehensive Meta Description -->
  <meta name="description" content="MediQ Antibiogram Management System: Advanced healthcare software for tracking, analyzing, and managing antimicrobial resistance patterns. Streamline hospital antibiotic stewardship, enhance infection control, and improve patient outcomes with data-driven insights.">
  
  <!-- Enhanced Keyword Strategy -->
  <meta name="keywords" content="
    MediQ Antibiogram Management System,
    Antimicrobial Resistance Tracking,
    Hospital Antibiotic Stewardship,
    Healthcare Data Analysis Platform,
    Infection Control Software,
    Antibiotic Sensitivity Testing,
    Microbiology Data Management,
    Hospital Epidemiology System,
    Antimicrobial Susceptibility Testing,
    Clinical Decision Support System,
    Hospital Infection Prevention,
    Antibiotic Resistance Monitoring,
    Healthcare Analytics Platform,
    Medical Laboratory Software,
    Patient Safety Monitoring,
    Hospital Data Management,
    Clinical Microbiology Software,
    Public Health Surveillance,
    Antibiotic Usage Tracking,
    Healthcare Quality Improvement,
    Electronic Antibiogram System,
    Hospital Pharmacy Management,
    Medical Data Visualization,
    Healthcare Compliance Software
  ">
  
  <!-- Author & Credibility -->
  <meta name="author" content="MediQ Healthcare Solutions">
  <meta name="robots" content="index, follow, max-image-preview:large, max-snippet:-1, max-video-preview:-1">
  
  <!-- Canonical URL -->
  <link rel="canonical" href="https://mediq.42web.io/antibiogram/">
  
  <!-- Open Graph for Social Sharing -->
  <meta property="og:type" content="website">
  <meta property="og:locale" content="en_US">
  <meta property="og:site_name" content="MediQ Healthcare Systems">
  <meta property="og:title" content="MediQ Antibiogram Management System | Healthcare Data Analytics">
  <meta property="og:description" content="Advanced software for antimicrobial resistance tracking, antibiotic stewardship, and hospital infection control with comprehensive data analytics and reporting.">
  <meta property="og:image" content="https://mediq.42web.io/assets/img/portfolio/antibiogram/1.png">
  <meta property="og:image:alt" content="MediQ Antibiogram Management System Dashboard Interface">
  <meta property="og:image:width" content="1200">
  <meta property="og:image:height" content="630">
  <meta property="og:url" content="https://mediq.42web.io/antibiogram/">
  
  <!-- Twitter Card -->
  <meta name="twitter:card" content="summary_large_image">
  <meta name="twitter:site" content="@mediq_health">
  <meta name="twitter:creator" content="@mediq_health">
  <meta name="twitter:title" content="MediQ Antibiogram Management System">
  <meta name="twitter:description" content="Healthcare software for antimicrobial resistance tracking and antibiotic stewardship in hospitals and clinical settings.">
  <meta name="twitter:image" content="https://mediq.42web.io/assets/img/portfolio/antibiogram/1.png">
  <meta name="twitter:image:alt" content="Antibiogram Management System Interface">
  
  <!-- Additional SEO Meta Tags -->
  <meta name="subject" content="Healthcare Software, Antimicrobial Resistance, Hospital Management">
  <meta name="classification" content="Healthcare Technology, Medical Software, Data Analytics">
  <meta name="language" content="en">
  <meta name="coverage" content="Worldwide">
  <meta name="distribution" content="global">
  <meta name="rating" content="General">
  <meta name="revised" content="2025-07-02">
  
  <!-- Application-Specific Meta Tags -->
  <meta name="application-name" content="MediQ Antibiogram Management">
  <meta name="apple-mobile-web-app-title" content="MediQ Antibiogram">
  <meta name="theme-color" content="#0EA5E9">
  
  <!-- Preconnect for Performance -->
  <link href="https://fonts.googleapis.com" rel="preconnect">
  <link href="https://fonts.gstatic.com" rel="preconnect" crossorigin>
  
  <!-- Fonts -->
  <link href="https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,100;0,300;0,400;0,500;0,700;0,900;1,100;1,300;1,400;1,500;1,700;1,900&family=Open+Sans:ital,wght@0,300;0,400;0,500;0,600;0,700;0,800;1,300;1,400;1,500;1,600;1,700;1,800&family=Quicksand:wght@300;400;500;600;700&display=swap" rel="stylesheet">
  
  <!-- Combined CSS Bundle -->
  <link href="assets/css/bundle.min.css" rel="stylesheet">
  
  <!-- Structured Data for Healthcare Software -->
  <script type="application/ld+json">
  {
    "@context": "https://schema.org",
    "@type": "SoftwareApplication",
    "name": "MediQ Antibiogram Management System",
    "description": "Healthcare software for tracking and analyzing antimicrobial resistance patterns in hospital settings",
    "url": "https://mediq.42web.io/antibiogram/",
    "applicationCategory": "MedicalApplication",
    "operatingSystem": "Web",
    "author": {
      "@type": "Organization",
      "name": "MediQ Healthcare Solutions",
      "url": "https://mediq.42web.io"
    },
    "datePublished": "2025-07-02",
    "featureList": [
      "Antimicrobial Resistance Tracking",
      "Antibiotic Sensitivity Analysis",
      "Hospital Epidemiology Reporting",
      "Infection Control Monitoring",
      "Patient Safety Analytics",
      "Antibiotic Stewardship Tools",
      "Clinical Decision Support",
      "Data Visualization Dashboard",
      "Automated Reporting",
      "Multi-hospital Data Aggregation",
      "Real-time Alert System",
      "Compliance Tracking",
      "Laboratory Integration",
      "Pharmacy Interface",
      "Mobile Access"
    ],
    "softwareRequirements": "Modern Web Browser",
    "screenshot": [
      "https://mediq.42web.io/assets/img/portfolio/antibiogram/1.png",
      "https://mediq.42web.io/assets/img/portfolio/antibiogram/2.png",
      "https://mediq.42web.io/assets/img/portfolio/antibiogram/3.png"
    ],
    "softwareVersion": "1.5.0",
    "offers": {
      "@type": "Offer",
      "availability": "https://schema.org/InStock",
      "category": "Healthcare Software"
    },
    "keywords": "antibiogram, antimicrobial resistance, healthcare analytics, hospital management"
  }
  </script>
  
  <!-- Additional Schema for Medical Organization -->
  <script type="application/ld+json">
  {
    "@context": "https://schema.org",
    "@type": "MedicalOrganization",
    "name": "MediQ Healthcare Systems",
    "description": "Healthcare technology solutions for antimicrobial resistance management and infection control",
    "url": "https://mediq.42web.io",
    "medicalSpecialty": "Infectious Diseases, Hospital Epidemiology, Pharmacy Management"
  }
  </script>
</head>

<body class="portfolio-details-page">

   <?php include_once ("includes/header.php") ?>

  <main class="main">

    <!-- Page Title -->
    <div class="page-title light-background">
      <div class="container d-lg-flex justify-content-between align-items-center">
        <h1 class="mb-2 mb-lg-0">Portfolio Details</h1>
        <nav class="breadcrumbs">
          <ol>
            <li><a href="index.php">Home</a></li>
            <li class="current">Portfolio Details</li>
          </ol>
        </nav>
      </div>
    </div><!-- End Page Title -->

    <!-- Portfolio Details Section -->
    <section id="portfolio-details" class="portfolio-details section">

      <div class="container" data-aos="fade-up" data-aos-delay="100">

        <div class="row gy-4">
          <div class="col-lg-6" data-aos="fade-right">
            <div class="portfolio-details-media">
              <div class="main-image">
                <div class="portfolio-details-slider swiper init-swiper" data-aos="zoom-in">
                  <script type="application/json" class="swiper-config">
                    {
                      "loop": true,
                      "speed": 1000,
                      "autoplay": {
                        "delay": 2000
                      },
                      "effect": "creative",
                      "creativeEffect": {
                        "prev": {
                          "shadow": true,
                          "translate": [0, 0, -400]
                        },
                        "next": {
                          "translate": ["100%", 0, 0]
                        }
                      },
                      "slidesPerView": 1,
                      "navigation": {
                        "nextEl": ".swiper-button-next",
                        "prevEl": ".swiper-button-prev"
                      }
                    }
                  </script>

                  <div class="swiper-wrapper">
                    <div class="swiper-slide">
                      <img src="assets/img/portfolio/antibiogram/1.png" alt="Antibiogram Management System Dashboard" class="img-fluid" width="800" height="600">
                    </div>
                    <div class="swiper-slide">
                      <img src="assets/img/portfolio/antibiogram/2.png" alt="Microbiology Lab Results Interface" class="img-fluid" loading="lazy" width="800" height="600">
                    </div>
                    <div class="swiper-slide">
                      <img src="assets/img/portfolio/antibiogram/3.png" alt="Antibiotic Resistance Analysis Report" class="img-fluid" loading="lazy" width="800" height="600">
                    </div>
                    <div class="swiper-slide">
                      <img src="assets/img/portfolio/antibiogram/4.png" alt="Patient Data Management for Microbiology" class="img-fluid" loading="lazy" width="800" height="600">
                    </div>
                    <div class="swiper-slide">
                      <img src="assets/img/portfolio/antibiogram/5.png" alt="Real-time Antibiotic Usage Statistics" class="img-fluid" loading="lazy" width="800" height="600">
                    </div>
                    <div class="swiper-slide">
                      <img src="assets/img/portfolio/antibiogram/6.png" class="img-fluid" alt="Interpretation and Reporting Panel" loading="lazy" width="800" height="600">
                    </div>
                    <div class="swiper-slide">
                      <img src="assets/img/portfolio/antibiogram/7.png" class="img-fluid" alt="Historical Data Filtering Overview" loading="lazy" width="800" height="600">
                    </div>
                  </div>
                    
                  <div class="swiper-button-prev"></div>
                  <div class="swiper-button-next"></div>
                </div>
              </div>

              <div class="thumbnail-grid" data-aos="fade-up" data-aos-delay="200">
                <div class="row g-2 mt-3">
                  <div class="col-3">
                    <img src="assets/img/portfolio/antibiogram/1.png" class="img-fluid glightbox" alt="Dashboard Preview" loading="lazy" width="200" height="150">
                  </div>
                  <div class="col-3">
                    <img src="assets/img/portfolio/antibiogram/2.png" class="img-fluid glightbox" alt="Lab Interface Preview" loading="lazy" width="200" height="150">
                  </div>
                  <div class="col-3">
                    <img src="assets/img/portfolio/antibiogram/3.png" class="img-fluid glightbox" alt="Analysis Report Preview" loading="lazy" width="200" height="150">
                  </div>
                  <div class="col-3">
                    <img src="assets/img/portfolio/antibiogram/4.png" class="img-fluid glightbox" alt="Patient Management Preview" loading="lazy" width="200" height="150">
                  </div>
                  <div class="col-3">
                    <img src="assets/img/portfolio/antibiogram/5.png" class="img-fluid glightbox" alt="Statistics View Preview" loading="lazy" width="200" height="150">
                  </div>
                  <div class="col-3">
                    <img src="assets/img/portfolio/antibiogram/6.png" class="img-fluid glightbox" alt="Reporting View Preview" loading="lazy" width="200" height="150">
                  </div>
                  <div class="col-3">
                    <img src="assets/img/portfolio/antibiogram/7.png" class="img-fluid glightbox" alt="Filtering View Preview" loading="lazy" width="200" height="150">
                  </div>
                </div>
              </div>

              <div class="tech-stack-badges" data-aos="fade-up" data-aos-delay="300">
                <span>Bootstrap</span>
                <span>JavaScript</span>
                <span>PHP</span>
                <span>CSS</span>
                <span>Git</span>
                <span>Photoshop</span>
                <span>MySQL</span>
                <span>HTML5</span>
              </div>
            </div>
          </div>

          <div class="col-lg-6" data-aos="fade-left">
            <div class="portfolio-details-content">
              <div class="project-meta">
                <div class="badge-wrapper">
                  <span class="project-badge">FullStack Development</span>
                  <span class="project-badge">Healthcare Technology</span>
                </div>
                <div class="date-client">
                  <div class="meta-item">
                    <i class="bi bi-calendar-check"></i>
                    <span>May 2025 - Present</span>
                  </div>
                  <div class="meta-item">
                    <i class="bi bi-buildings"></i>
                    <span>Malitha Tishamal</span>
                  </div>
                </div>
              </div>

              <h2 class="project-title">MediQ - Antibiogram Management System</h2>

              <div class="project-website">
                <i class="bi bi-link-45deg"></i>
                <a href="https://mediq.42web.io/antibiogram/" target="_blank">https://mediq.42web.io/antibiogram/</a>
              </div>

              <div class="project-overview">
                <p class="lead">
                  <strong>🔬 Excited to Share: Antibiogram Management System</strong>
                </p>
                <p>
                  I'm thrilled to introduce my latest healthcare technology project — a Cumulative Antibiogram Management System designed to revolutionize how hospitals and laboratories track, analyze, and act on antimicrobial resistance (AMR) data.
                </p>

                <h4>✨ What Makes This System Unique</h4>

                <h5>📊 Smart Data Analytics</h5>
                <ul>
                  <li>Interactive antibiogram summaries with percentage and raw count views</li>
                  <li>Real-time susceptibility pattern analysis across multiple antibiotics</li>
                  <li>Visual color-coding for instant resistance recognition</li>
                  <li>Dynamic filters by Infection Type, Hospital, and Organism Group (Gram-positive/Gram-negative)</li>
                </ul>

                <h5>🔒 Robust Admin Management</h5>
                <ul>
                  <li>Full user account lifecycle management</li>
                  <li>Role-based access control with granular permissions</li>
                  <li>Secure authentication & authorization</li>
                  <li>Active/inactive admin status tracking for transparency</li>
                </ul>

                <h5>📈 Clinical Decision Support</h5>
                <ul>
                  <li>Automated susceptibility interpretation</li>
                  <li>Comprehensive organism–antibiotic resistance mapping</li>
                  <li>Data-driven insights to strengthen antimicrobial stewardship</li>
                </ul>

                <div class="accordion project-accordion" id="portfolio-details-projectAccordion">
                  <!-- Project Overview -->
                  <div class="accordion-item" data-aos="fade-up">
                    <h2 class="accordion-header">
                      <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#portfolio-details-collapse-1" aria-expanded="true" aria-controls="collapseOne">
                        <i class="bi bi-clipboard-data me-2"></i> Project Overview
                      </button>
                    </h2>
                    <div id="portfolio-details-collapse-1" class="accordion-collapse collapse show" data-bs-parent="#portfolio-details-projectAccordion">
                      <div class="accordion-body">
                        <p>
                          The MediQ Antibiogram Management System is a comprehensive healthcare technology solution designed to address the critical challenge of antimicrobial resistance (AMR) monitoring. This platform enables hospitals and laboratories to systematically collect, analyze, and visualize antimicrobial susceptibility data, empowering healthcare professionals with evidence-based insights for informed antibiotic prescribing decisions.
                        </p>
                        <p>
                          By centralizing AMR data and providing intuitive analytical tools, the system supports antimicrobial stewardship programs and helps combat the growing global threat of antibiotic resistance.
                        </p>
                      </div>
                    </div>
                  </div>

                  <!-- The Challenge -->
                  <div class="accordion-item" data-aos="fade-up" data-aos-delay="100">
                    <h2 class="accordion-header">
                      <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#portfolio-details-collapse-2" aria-expanded="false" aria-controls="collapseTwo">
                        <i class="bi bi-exclamation-diamond me-2"></i> The Challenge
                      </button>
                    </h2>
                    <div id="portfolio-details-collapse-2" class="accordion-collapse collapse" data-bs-parent="#portfolio-details-projectAccordion">
                      <div class="accordion-body">
                        <p>
                          Antimicrobial resistance is one of the top global public health threats, with ineffective antibiotics leading to longer hospital stays, higher medical costs, and increased mortality. Traditional methods of tracking and analyzing antibiogram data are often:
                        </p>
                        <ul>
                          <li>Manual and time-consuming processes</li>
                          <li>Limited in analytical capabilities</li>
                          <li>Not easily accessible to clinicians at the point of care</li>
                          <li>Difficult to compare across time periods or institutions</li>
                          <li>Lacking real-time updates and visualizations</li>
                        </ul>
                        <p>
                          These limitations hinder effective antimicrobial stewardship and delay the implementation of data-driven treatment protocols.
                        </p>
                      </div>
                    </div>
                  </div>

                  <!-- The Solution -->
                  <div class="accordion-item" data-aos="fade-up" data-aos-delay="200">
                    <h2 class="accordion-header">
                      <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#portfolio-details-collapse-3" aria-expanded="false" aria-controls="collapseThree">
                        <i class="bi bi-award me-2"></i> The Solution
                      </button>
                    </h2>
                    <div id="portfolio-details-collapse-3" class="accordion-collapse collapse" data-bs-parent="#portfolio-details-projectAccordion">
                      <div class="accordion-body">
                        <p>
                          The MediQ Antibiogram Management System addresses these challenges through a comprehensive digital platform that:
                        </p>
                        <ul>
                          <li><strong>Automates data collection and analysis</strong> - Streamlines the process from laboratory results to actionable insights</li>
                          <li><strong>Provides interactive visualizations</strong> - Enables quick interpretation of complex resistance patterns</li>
                          <li><strong>Supports evidence-based prescribing</strong> - Delivers current susceptibility data to clinicians when needed</li>
                          <li><strong>Facilitates institutional comparisons</strong> - Allows benchmarking against regional or national data</li>
                          <li><strong>Enhances antimicrobial stewardship</strong> - Provides tools for monitoring and improving antibiotic use</li>
                        </ul>
                        <p>
                          This solution represents the intersection of clinical microbiology, data science, and user-centered design, aiming to drive meaningful impact in antimicrobial resistance monitoring.
                        </p>
                      </div>
                    </div>
                  </div>
                </div>

                <div class="project-features" data-aos="fade-up" data-aos-delay="300">
                  <h3><i class="bi bi-stars"></i> Key Features</h3>
                  <div class="row g-3">
                    <div class="col-md-6">
                      <ul class="feature-list">
                        <li><i class="bi bi-check2-circle"></i> CSV/Excel data import</li>
                        <li><i class="bi bi-check2-circle"></i> Upload historical data for trend analysis</li>
                        <li><i class="bi bi-check2-circle"></i> Multi-format report generation</li>
                        <li><i class="bi bi-check2-circle"></i> Download access for all reports</li>
                      </ul>
                    </div>
                    <div class="col-md-6">
                      <ul class="feature-list">
                        <li><i class="bi bi-check2-circle"></i> Real-time dashboard analytics</li>
                        <li><i class="bi bi-check2-circle"></i> Secure multi-admin environment</li>
                        <li><i class="bi bi-check2-circle"></i> Fully mobile-responsive design</li>
                        <li><i class="bi bi-check2-circle"></i> Role-based access control</li>
                      </ul>
                    </div>
                  </div>
                </div>

                <div class="healthcare-impact mt-4" data-aos="fade-up" data-aos-delay="400">
                  <h3><i class="bi bi-heart-pulse"></i> Healthcare Impact</h3>
                  <p>This system empowers healthcare professionals to:</p>
                  <ul>
                    <li>Make evidence-based antibiotic prescribing decisions</li>
                    <li>Strengthen AMR surveillance and control</li>
                    <li>Improve patient outcomes through actionable insights</li>
                    <li>Enhance laboratory workflow efficiency with smart filtering and data visualization</li>
                    <li>Support antimicrobial stewardship programs with reliable data</li>
                  </ul>
                </div>

                <div class="technical-excellence mt-4" data-aos="fade-up" data-aos-delay="500">
                  <h3><i class="bi bi-gear"></i> Technical Excellence</h3>
                  <p>Built using modern web technologies, ensuring:</p>
                  <ul>
                    <li><strong>Scalability</strong> - Handles growing datasets and user loads</li>
                    <li><strong>Security</strong> - Protects sensitive patient and laboratory data</li>
                    <li><strong>Performance</strong> - Delivers fast, responsive user experience</li>
                    <li><strong>Cross-platform compatibility</strong> - Works seamlessly across all devices</li>
                  </ul>
                </div>

                <div class="cta-buttons" data-aos="fade-up" data-aos-delay="600">
                  <a href="https://mediq.42web.io/antibiogram/" target="_blank" class="btn-view-project">View Live Project</a>
                  <a href="portfolio-details-spid-web.php" class="btn-next-project">Next Project <i class="bi bi-arrow-right"></i></a>
                </div>
              </div>
            </div>
          </div>
        </div>

      </div>

    </section><!-- /Portfolio Details Section -->

  </main>

<?php include_once ("includes/footer.php") ?>

  <!-- Scroll Top -->
  <a href="#" id="scroll-top" class="scroll-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>



</body>

</html>